# AMSKY01 Sensor Data Viewer

[![PyPI version](https://badge.fury.io/py/amsky01.svg)](https://badge.fury.io/py/amsky01)
[![Python versions](https://img.shields.io/pypi/pyversions/amsky01.svg)](https://pypi.org/project/amsky01/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Test Package](https://github.com/AstroMeters/AMSKY01/actions/workflows/test.yml/badge.svg)](https://github.com/AstroMeters/AMSKY01/actions/workflows/test.yml)

Real-time visualization and data logging tool for AMSKY01 atmospheric sensor data. This package provides comprehensive tools for monitoring and analyzing sensor data from hygro, light, and thermal sensors.

## Features

- **Real-time Data Visualization**: Live display of sensor readings with interactive CLI interface
- **Multi-sensor Support**: 
  - Humidity and temperature sensors (with dew point calculation)
  - Light sensors (TSL2591) with automatic gain and integration time handling
  - Thermal sensors (MLX90641) with 4-quadrant temperature mapping
- **Data Logging**: Automatic CSV logging with 10-minute file rotation
- **Flexible Interface**: Both CLI and programmatic access to sensor data
- **Serial Communication**: Robust serial port handling with auto-reconnection
- **Cross-platform**: Works on Linux, Windows, and macOS

## Installation

### From PyPI (recommended)

```bash
pip install amsky01
```

### From source

```bash
git clone https://github.com/AstroMeters/AMSKY01.git
cd AMSKY01
pip install -e .
```

## Usage

### Command Line Tools

After installation, three command-line tools are available:

#### 1. Sensor Viewer (Main Application)
```bash
amsky01-viewer --port /dev/ttyUSB0 --baudrate 115200 --log
```

#### 2. Debug Tool
```bash
amsky01-debug --port /dev/ttyUSB0
```

#### 3. Data Plotting
```bash
amsky01-plot --log-dir ./sensor_logs
```

### Command Line Arguments

- `--port`: Serial port (default: `/dev/ttyUSB0`)
- `--baudrate`: Baud rate (default: `115200`)
- `--log`: Enable CSV data logging
- `--log-dir`: Directory for log files (default: `sensor_logs`)
- `--cli`: Use CLI interface (requires curses)
- `--gui`: Use GUI interface (requires PySide6)

### Programmatic Usage

```python
from sensor_viewer import SensorData, SerialReader, DataLogger

# Initialize sensor data container
sensor_data = SensorData()

# Start serial reader
reader = SerialReader('/dev/ttyUSB0', 115200, sensor_data)
reader.start()

# Get latest sensor readings
data = sensor_data.get_latest_data()
print(f"Temperature: {data['hygro']['temp']}°C")
print(f"Humidity: {data['hygro']['humid']}%")
print(f"Light: {data['light']['lux']}")
print(f"Thermal Center: {data['thermal']['center']}°C")

# Stop reader when done
reader.stop()
```

## Data Format

The AMSKY01 device sends data in CSV format over serial connection:

- **Hygro data**: `$hygro,temperature,humidity`
- **Light data**: `$light,lux,raw,ir,gain,integration_time`
- **Thermal data**: `$thermal,top_left,top_right,bottom_left,bottom_right,center`

## Sensor Specifications

### Humidity/Temperature Sensor
- Temperature range: -40°C to +85°C
- Humidity range: 0-100% RH
- Automatic dew point calculation using Magnus formula

### Light Sensor (TSL2591)
- Dynamic range: 188 µlux to 88,000 lux
- Automatic gain control (1x, 25x, 428x, 9876x)
- Configurable integration time
- IR and full spectrum measurements

### Thermal Sensor (MLX90641)
- Temperature range: -40°C to +300°C
- 4-quadrant temperature mapping
- Center point measurement

## Data Logging

When logging is enabled, data is automatically saved to CSV files with the following features:

- **File Rotation**: New file every 10 minutes
- **Timestamp**: Both UTC timestamp and Unix timestamp
- **All Sensors**: Combined data from all sensors in single file
- **Directory Structure**: Organized by date and time

### Log File Format

```csv
timestamp_utc,unix_timestamp,hygro_temp,hygro_humid,light_lux_calc,light_raw,light_ir,light_gain,light_integration,thermal_tl,thermal_tr,thermal_bl,thermal_br,thermal_center
2024-08-24T14:00:00.000Z,1724508000.000,25.3,65.2,1250.5,1024,512,25,100,24.8,25.1,24.9,25.0,25.0
```

## Requirements

- Python 3.8+
- PySide6 >= 6.9.0 (for GUI)
- pyqtgraph >= 0.13.0 (for plotting)
- pyserial >= 3.5 (for serial communication)
- numpy >= 1.22.0 (for calculations)
- psutil (for system monitoring)

## Development

### Setup Development Environment

```bash
git clone https://github.com/AstroMeters/AMSKY01.git
cd AMSKY01
pip install -e .[dev]
```

### Code Formatting

```bash
black sw/
flake8 sw/
```

### Testing

```bash
pytest
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests and linting
5. Submit a pull request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support, please:

- Check the [Issues](https://github.com/AstroMeters/AMSKY01/issues) page
- Contact: info@astrometers.eu

## Changelog

### Version 1.0.0
- Initial release
- Real-time sensor data visualization
- CSV data logging with automatic rotation
- Cross-platform support
- CLI and GUI interfaces
- Automatic sensor calibration and scaling
